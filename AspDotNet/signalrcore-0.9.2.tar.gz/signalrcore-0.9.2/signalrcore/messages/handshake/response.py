class HandshakeResponseMessage(object):

    def __init__(self, error):
        self.error = error
